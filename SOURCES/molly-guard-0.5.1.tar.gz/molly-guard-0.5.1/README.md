molly-guard
===========

Molly Guard for RHEL

Protects machines from accidental shutdowns/reboots

This is a fork of https://github.com/tmhorne/molly-guard with some updates to work on CentOS 6 and 7. The man page has been included prebuilt so the XSLT dependecies can be avoided.
If you have any questions about the use of this package or concerns about the LICENSE, please contact me at tjcelaya@gmail.com

README from fork follows.

> This is a port of molly-guard from Debian to RHEL and derivatives.

> Original page: http://packages.debian.org/source/sid/molly-guard


> It was ported by (I'm assuming) Lazarus at:

> http://lazarus-corner-of-the-world.blogspot.com/2012/11/rpm-builds-for-molly-guard.html


> I didn't want the code to disappear some day, so I decided to upload it to github.
